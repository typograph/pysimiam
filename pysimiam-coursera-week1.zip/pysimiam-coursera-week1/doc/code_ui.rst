Graphical Interface
====================================

Drawing
--------

.. autoclass:: renderer.Renderer
    :members:

.. autoclass:: qt_renderer.QtRenderer


UI
---------

.. _ui-sim-queue:
    
Interaction between GUI and the Simulator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The interaction is serialized

PyQt4 implementation
^^^^^^^^^^^^^^^^^^^^

.. automodule:: qt_mainwindow
    :members:
        
.. automodule:: qt_dockwindow
    :members:
