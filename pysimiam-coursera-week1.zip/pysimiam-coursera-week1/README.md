To run: 

> python qtsimiam_week1.py

or

> ./qtsimiam_week1.py

Load your own supervisors and controllers into the development folders following the supervisor and controller templates.

To compile the documentation, go into the ./docs folder and type:

> make clean

> make html

