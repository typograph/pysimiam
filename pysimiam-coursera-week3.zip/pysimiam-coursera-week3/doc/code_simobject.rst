SimObject
====================================

Pose
------------------------------

.. automodule:: pose
    :members:

SimObject and simple shapes
-------------------------------

.. automodule:: simobject
    :member-order: bysource
    :members:
